<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<span id="laterpay-page-caching-mode" data-post-id="<?php echo $laterpay['post_id']; ?>"></span>
