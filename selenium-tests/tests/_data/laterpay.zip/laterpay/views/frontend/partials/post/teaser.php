<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<?php echo '<div class="laterpay-teaser-content">' . $laterpay['teaser_content'] . '</div>'; ?>
