<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<iframe id="lp_identify-iframe" src="<?php echo $identify_link; ?>" style="height:1px; left:-9000px; position:absolute; width:1px;"></iframe>
