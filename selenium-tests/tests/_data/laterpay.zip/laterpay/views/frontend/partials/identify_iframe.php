<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<iframe src="<?php echo $identify_link; ?>" id="laterpay-identify" style="height:1px; left:-9000px; position:absolute; width:1px;"></iframe>
